package test;

import java.util.ArrayList;
import java.util.Scanner;

public class ArticleControler {
	ArticleView articleView = new ArticleView();
	ArticleRepository repo = new ArticleRepository();
	Member loginedMember = null;
	Scanner sc = new Scanner(System.in);
	ArrayList<Replis> replis = new ArrayList<>();
	int replyNum=0;
	
	public void doCommand() {
		repo.addtestdata();
		articleView.help();
		while(true){
			cmd();
			String cmd = sc.nextLine();
			
		if(cmd.equals("help")) {
			articleView.help();
			}
		else if(cmd.equals("article add")) {
			addArticles();	
			}
		else if(cmd.equals("list")) {
			articleView.printArticles(repo.getArticleList());
			}
		else if(cmd.equals("search")) {
			searchArticles();
			}
		else if(cmd.equals("read")) {
			read();
			}
	}
}
	private void cmd() {
		if(loginedMember!=null) {
			System.out.printf("명령어를 입력해주세요 : \n");
			System.out.printf("(%s(%s)) >> \n",loginedMember.getMemberId(),loginedMember.getMemberNickname());
			}

		else {
			System.out.println("명령어를 입력해주세요 : ");
			System.out.println(">> ");
		}	
	}
	public void addArticles() {
		if(loginedMember!=null) {
			System.out.print("제목을 입력해주세요 : ");
			String title = sc.nextLine();
			System.out.print("내용을 입력해주세요 : ");
			String body = sc.nextLine();
		
			System.out.printf("등록날짜 : %s\n",Util.getCurrentDate());
			System.out.printf("작성자 : %s\n",loginedMember.getMemberNickname());		
			System.out.println("게시물이 저장되었습니다.");
			repo.addArticle(title, body,loginedMember.getMemberNickname());
			}
		
		else {
			System.out.println("로그인이 필요한 기능입니다.");
		}
	}
	public void searchArticles() {
		System.out.println("검색 키워드를 입력해주세요 : ");
		String keyword = sc.nextLine();
		
		ArrayList<Article> searchedList = (ArrayList<Article>) repo.getSearchedArticleList(keyword);
		articleView.printArticles(searchedList);
	}
	public void read() {
		if(loginedMember==null) {
			System.out.println("로그인이 필요한 기능입니다.");
			}
		
		else {
			System.out.println("상세보기할 게시물 번호를 입력해주세요 : ");
			
			int targetId = Integer.parseInt(sc.nextLine());
			Article article = repo.getArticleOne(targetId);
		
			if(article == null) {
				System.out.println("없는 게시물입니다.");
				} 
			else {
				repo.increaseReadCnt(article);
				articleView.printArticlesDetail(article);
				}
		
			while(true) {
				System.out.println("상세보기 기능을 선택해주세요(1. 댓글 등록, 2. 좋아요, 3. 수정, 4. 삭제, 5. 목록으로) : ");
				String readCmd = sc.nextLine();
				
				if(readCmd.equals("1")) {
					reply(article);	
					}
				else if(readCmd.equals("2")) {
					repo.recommend(article);
					}
				else if(readCmd.equals("3")) {
					update(article);
					break;
					}
				else if(readCmd.equals("4")) {
					deleteArticle(article);
					break;
					}
				else if(readCmd.equals("5")) {
					break;
				}
				else {
					System.out.println("지원하지 않는 기능입니다.");
					break;
				}
				
			}
		}
	}
	public void update(Article article) {
		if(article.getNickname()==loginedMember.getMemberNickname()) {
			System.out.println("새제목 : ");
			String title = sc.nextLine();
			System.out.println("새내용 : ");
			String body = sc.nextLine();
			
			repo.updateArticle(article, title, body);
			System.out.println("수정이 완료되었습니다.");
			articleView.printArticles(repo.getArticleList());
		}
		else {
			System.out.println("작성자만 수정할 수 있습니다.");
		}
	}
	

	private void reply(Article article) {
		System.out.println("댓글 내용을 입력해주세요 : ");
		String articleReply = sc.nextLine();
		System.out.println("댓글이 등록되었습니다.");
		Replis reply = new Replis(replyNum,loginedMember.getMemberNickname(),articleReply,Util.getCurrentDate());
		replis.add(reply);
		replyNum++;
		for(int i=0;i<replis.size();i++) {
				if(i==0) {
					System.out.println("======= 댓글 =======");
				}
				System.out.printf("내용 : %s\n", replis.get(i).replisBody);
				System.out.printf("작성자 : %s\n", replis.get(i).replisNickname);
				System.out.printf("작성일 : %s\n", replis.get(i).replisRegDate);
				System.out.println("===================");
				}
			}
	
	public void deleteArticle(Article article) {		
		if(article.getNickname()==loginedMember.getMemberNickname()) {
			repo.deleteArticle(article);		
			System.out.println("삭제가 완료되었습니다.");
		}
		else {
			System.out.println("작성자만 삭제할 수 있습니다.");
		}
	}
	
	
}