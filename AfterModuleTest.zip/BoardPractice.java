package test;

import java.util.ArrayList;
import java.util.Scanner;

public class BoardPractice {
//	private final int LOGIN_SUCCESS = 0;
//	private final int LOGIN_FAILED_ID = 1;
//	private final int LOGIN_FAILED_PW = 2;
	doLoginFlag flag;
	ArrayList<Article> articles = new ArrayList<>();
	ArrayList<Replis> replis = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	ArticleView articleView = new ArticleView();
	ArticleRepository repo = new ArticleRepository();
	Member loginedMember = null;

	
//	리팩토링View V
//	제어 C -> Board 데이터가 필요하면 M (repo)에서 꺼내오고 실행. 
//	데이터 M ->MV 모델과 뷰를 C제어한다MVC 
	// 게시물, 회원으로 분리. 게시판도 질문게시판,자유게시판등 여러개 필요하기에 모듈화필요. 회원도 마찬가지.
	public void run(){
			
	}
}