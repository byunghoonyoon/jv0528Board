package test;

public class ExtendTest {

	public static void main(String[] args) {
		
		Animal a1 = new Animal();
//		a1.move();
		
		Dog a2= new Dog();
//		a2.bark();
		
		Cat c3 = new Cat();
//		c3.grooming();
//		
//		c3.move();
		Animal d4 =new Dog();
		
		Animal[] animals = {a1,a2,c3,d4};
		for(int i=0;i<4;i++) {
			animals[i].move();
		}
	}
}

class Animal {
	public void move() {
		System.out.println("animal move");
	}
}
class Dog extends Animal{
	public void bark() {
		super.move();
		System.out.println("bow wow");
	}
}
class Cat extends Animal{
	public void grooming() {
		System.out.println("groooo");
	}
}
