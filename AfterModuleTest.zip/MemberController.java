package test;

import java.util.Scanner;

public class MemberController {
	ArticleView articleView = new ArticleView();
	ArticleRepository repo = new ArticleRepository();
	Scanner sc = new Scanner(System.in);
	Member loginedMember = null;
	
	public void doCommand() {
		String cmd = sc.nextLine();
		
		if(cmd.equals("signup")) {
			addMember();
			}
		else if(cmd.equals("login")) {
			login();
			}
		else if(cmd.equals("logout")) {
			doLogout();
			}
		else if(cmd.equals("mlist")) {
			repo.getmemberList();
	}
		
}
	public void addMember() {
		System.out.println("==== 회원가입을 진행합니다. ====");
		System.out.println("아이디를 입력해주세요 : ");
		String memberId = sc.nextLine();
		System.out.println("비밀번호를 입력해주세요 : ");
		String memberPassword = sc.nextLine();
		System.out.println("닉네임을 입력해주세요 : ");
		String memberNickname = sc.nextLine();
		System.out.println("==== 회원가입이 완료되었습니다. ====");
		repo.doAddMember(memberId,memberPassword,memberNickname);
		}
	
	public void login() {
		System.out.println("아이디를 입력해주세요 : ");
		String loginId = sc.nextLine();
		System.out.println("비밀번호를 입력해주세요 : ");
		String loginPassword = sc.nextLine();
		//		repo.doLogin(loginId,loginPassword);
		//repo.doLogin 결과 return으로 1,2,3출력됨.때문에 int 변수에 값을 저장해줘야함.
		doLoginFlag loginResult = repo.doLogin(loginId, loginPassword);
		
//		if(loginResult==1) {
//			System.out.println("로그인 성공입니다.");
//		}else if(loginResult==2) {
//			System.out.println("없는 아이디거나 틀린 아이디입니다.");
//		}else {
//			System.out.println("비밀번호가 틀렸습니다.");
		 // 1,2 로 직접 받는것보다 위의 final int값으로 받는게 더 정확.
			if(loginResult==doLoginFlag.LOGIN_SUCCESS) {
				Member member = repo.getMemberByLoginId(loginId);
				loginSuccessProcess(member);
					
				}else if(loginResult==doLoginFlag.LOGIN_FAILEDID) {
					System.out.println("없는 아이디거나 틀린 아이디입니다.");
					
				}else {
					System.out.println("비밀번호가 틀렸습니다.");
				}
		}
	
	private void loginSuccessProcess(Member member){//로그인유저 정보 세팅. 
		System.out.printf("%s님 안녕하세요!\n",member.getMemberNickname());
		loginedMember = member;
	}
	private void doLogout() {
		if(loginedMember==null) {
			System.out.println("로그인이 필요한 기능입니다.");
			}
		else {
			loginedMember = null;
		}
	}
}
