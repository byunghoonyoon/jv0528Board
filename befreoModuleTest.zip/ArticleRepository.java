package test;
import java.util.ArrayList;
import java.util.Scanner;

enum doLoginFlag{
	LOGIN_SUCCESS,
	LOGIN_FAILEDID,
	LOGIN_FAILEDPW
}
public class ArticleRepository {
	doLoginFlag flag;
	int articleId = 4;
	int View = 0;
	int memberNum=0;
	int Recommend = 0;
//	private final int LOGIN_SUCCESS = 0;
//	private final int LOGIN_FAILED_ID = 1;
//	private final int LOGIN_FAILED_PW = 2;
	
	Scanner sc = new Scanner(System.in);
	
	ArrayList<Article> articles = new ArrayList<>();
	ArrayList<Member> members = new ArrayList<>();

	public void addtestdata() {
		ArrayList<String> emptyReply = new ArrayList<>();
		Article a1 = new Article(1,"제목1","내용1",10,"익명",Util.getCurrentDate(),0,emptyReply);
		Article a2 = new Article(2,"제목2","내용2",30,"익명",Util.getCurrentDate(),0,emptyReply);
		Article a3 = new Article(3,"제목3","내용3",20,"익명",Util.getCurrentDate(),0,emptyReply);
		
		articles.add(a1);
		articles.add(a2);
		articles.add(a3);
		
		Member m1 = new Member("qqqq","qqqq","병훈",memberNum);
		Member m2 = new Member("wwww","wwww","영배",memberNum);
		
		members.add(m1);
		members.add(m2);
		}
	
	public void getmemberList(){
		for(int i=0;i<members.size();i++) {
			System.out.printf("%s %s\n",members.get(i).memberId,members.get(i).memberNickname);
		}
	}
	
	public ArrayList<Article> getArticleList(){
		return articles;
	}
	
	public void updateArticle(Article article, String title, String body) {
		article.setTitle(title);
		article.setBody(body);
		
	}
	
	public void deleteArticle(Article article) {
		articles.remove(article);
	}
	
	public void addArticle(String title, String body, String Nickname) {
		ArrayList<String> emptyReply = new ArrayList<>();
		Article article = new Article(articleId, title, body,View,Nickname,Util.getCurrentDate(),0,emptyReply);
		articles.add(article);
		articleId++;
	}


	public Article getArticleOne(int targetId) {
		for(int i=0;i<articles.size();i++) {
			if(targetId-1==i) {
				return articles.get(i);
			}
		}
		return null;
	}
	public ArrayList<Article> getSearchedArticleList(String keyWord) {
		ArrayList<Article> searchedArticleList = new ArrayList<>();
		
		for(int i=0;i<articles.size();i++) {
			if(articles.get(i).title.contains(keyWord)) {
					searchedArticleList.add(articles.get(i));
				}
			}
			return searchedArticleList;
		}
	
	public void recommend(Article article) {
		article.setRecommend(article.getRecommend()+1);
		
	}
	
	public void increaseReadCnt(Article article) {
		article.setView(article.getView()+1);
	}
	
	public Member getMemberByLoginId(String loginId){ // 리턴 받기위한 자료형입력. Member받을거기때문에 members get~~~임. 리턴안할거면 void.
		for(int i=0;i<members.size();i++){
			Member member = members.get(i);
			
			if(members.get(i).memberId.equals(loginId)) {
				return member;
			}
		}
		return null;
	}

	public boolean checkMemberPassword(Member member, String loginPw) {
			if(member.getMemberPassword().equals(loginPw)) {
				return true;
			}
			return false;
	}
	//0.로그인성공 1.아이디틀림 2.비번틀림 012으로 받을거기때문에 int로 작성, return 0 1 2  ;
	public doLoginFlag doLogin(String loginId,String loginPw) { //
		
		Member member = getMemberByLoginId(loginId);
		if(member==null) {
			return doLoginFlag.LOGIN_FAILEDID;  //System.out.println("없는 아이디입니다.");
		}else if (checkMemberPassword(member,loginPw)) { // Member member, String loginPw 받지않고 주는값이기때문에 Member,String없어야함.
			return doLoginFlag.LOGIN_SUCCESS;
		} else {
			return doLoginFlag.LOGIN_FAILEDPW;
		}
	}


	public void doAddMember(String memberId, String memberPassword, String memberNickname) {
		Member member = new Member(memberId,memberPassword,memberNickname,memberNum);
		members.add(member);
		memberNum++;
	}


}

