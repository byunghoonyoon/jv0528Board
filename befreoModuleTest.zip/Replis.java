package test;

public class Replis {
		int replisID;
		String replisNickname;
		String replisBody;
		String replisRegDate;
			public Replis(int replisID,String replisNickname,String replisBody,String replisRegDate) {
				this.replisNickname=replisNickname;
				this.replisID=replisID;
				this.replisBody=replisBody;
				this.replisRegDate=replisRegDate;
			}
			public int getReplisID() {
				return replisID;
			}
			public void setReplisID(int replisID) {
				this.replisID = replisID;
			}
			public String getReplisNickname() {
				return replisNickname;
			}
			public void setReplisNickname(String replisNickname) {
				this.replisNickname = replisNickname;
			}
			public String getReplisBody() {
				return replisBody;
			}
			public void setReplisBody(String replisBody) {
				this.replisBody = replisBody;
			}
			public String getReplisRegDate() {
				return replisRegDate;
			}
			public void setReplisRegDate(String replisRegDate) {
				this.replisRegDate = replisRegDate;
			}

	}


