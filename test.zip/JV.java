package test;

public class JV {

		public static void main(String[] args) {
		BoardPractice board = new BoardPractice();
		board.run();
		}
}
