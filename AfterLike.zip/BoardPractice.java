package test;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;

public class BoardPractice {
//	private final int LOGIN_SUCCESS = 0;
//	private final int LOGIN_FAILED_ID = 1;
//	private final int LOGIN_FAILED_PW = 2;
	doLoginFlag flag;

	ArrayList<Article> articles = new ArrayList<>();
	ArticleView articleView = new ArticleView();
	ArticleRepository repo = new ArticleRepository();
	Scanner sc = new Scanner(System.in);
	Member loginedMember = null;
	
	
//	리팩토링View V
//	제어 C -> Board 데이터가 필요하면 M (repo)에서 꺼내오고 실행. 
//	데이터 M ->MV 모델과 뷰를 C제어한다MVC 
	// 게시물, 회원으로 분리. 게시판도 질문게시판,자유게시판등 여러개 필요하기에 모듈화필요. 회원도 마찬가지.
	public void run(){
			repo.addtestdata();
			articleView.help();
			while(true){
				cmd();
				String cmd = sc.nextLine();
				
			if(cmd.equals("help")) {
				articleView.help();
				}
			else if(cmd.equals("article add")) {
				addArticles();	
				}
			else if(cmd.equals("list")) {
				articleView.printArticles(repo.getArticleList());
				}
			else if(cmd.equals("search")) {
				searchArticles();
				}
			else if(cmd.equals("read")) {
				read();
				}
			else if(cmd.equals("signup")) {
				addMember();
				}
			else if(cmd.equals("login")) {
				login();
				}
			else if(cmd.equals("logout")) {
				doLogout();
				}
			else if(cmd.equals("exit")){
				System.out.println("시스템을 종료합니다.");
				break;
				}
			else if(cmd.equals("mlist")) {
				repo.getmemberList();
			}
			else {
				System.out.println("잘못된 명령어입니다.");
				}
		}
		
	}
	

	private void cmd() {
		if(loginedMember!=null) {
			System.out.printf("명령어를 입력해주세요 : \n");
			System.out.printf("(%s(%s)) >> \n",loginedMember.getMemberId(),loginedMember.getMemberNickname());
			}

		else {
			System.out.println("명령어를 입력해주세요 : ");
			System.out.println(">> ");
		}	
	}


	public void searchArticles() {
		System.out.println("검색 키워드를 입력해주세요 : ");
		String keyword = sc.nextLine();
		
		ArrayList<Article> searchedList = (ArrayList<Article>) repo.getSearchedArticleList(keyword);
		articleView.printArticles(searchedList);
	}
	
	public void addArticles() {
		if(loginedMember!=null) {
			System.out.print("제목을 입력해주세요 : ");
			String title = sc.nextLine();
			System.out.print("내용을 입력해주세요 : ");
			String body = sc.nextLine();
		
			System.out.printf("등록날짜 : %s\n",Util.getCurrentDate());
			System.out.printf("작성자 : %s\n",loginedMember.getMemberNickname());		
			System.out.println("게시물이 저장되었습니다.");
			repo.addArticle(title, body,loginedMember.getMemberNickname());
			}
		
		else {
			System.out.println("로그인이 필요한 기능입니다.");
		}
	}
	public void update(Article article) {
		if(article.getNickname()==loginedMember.getMemberNickname()) {
			System.out.println("새제목 : ");
			String title = sc.nextLine();
			System.out.println("새내용 : ");
			String body = sc.nextLine();
			
			repo.updateArticle(article, title, body);
			System.out.println("수정이 완료되었습니다.");
			articleView.printArticles(repo.getArticleList());
		}
		else {
			System.out.println("작성자만 수정할 수 있습니다.");
		}
	}
	public void read() {
		if(loginedMember==null) {
			System.out.println("로그인이 필요한 기능입니다.");
			}
		
		else {
			System.out.println("상세보기할 게시물 번호를 입력해주세요 : ");
			
			int targetId = Integer.parseInt(sc.nextLine());
			Article article = repo.getArticleOne(targetId);
		
			if(article == null) {
				System.out.println("없는 게시물입니다.");
				} 
			else {
				repo.increaseReadCnt(article);
				articleView.printArticlesOnly(article);
				readprocess(article);
				}
		
		}
	}
		private void readprocess(Article article) {
			while(true) {
				System.out.println("상세보기 기능을 선택해주세요(1. 댓글 등록, 2. 좋아요, 3. 수정, 4. 삭제, 5. 목록으로) : ");
				String readCmd = sc.nextLine();
				
				if(readCmd.equals("1")) {
					addReply(article);
					ArrayList<Replis> replis = repo.getRepliesByArticleId(article.getArticleId());
					articleView.printArticlesDetail(article, replis);
					}
				else if(readCmd.equals("2")) {
					String checkUser = loginedMember.getMemberId();
					String regDate = Util.getCurrentDate();
//					boolean target = repo.checkLikeByUserId(checkUser,article);
					if(repo.checkLikeByUserId(checkUser,article)) {
						System.out.println("이미 좋아요를 체크하셨습니다.");
//						deleteLike(target);
//						article.setRecommend(article.getRecommend()-1);
//						articleView.printArticlesOnly(article);
					}
					else {
						repo.addRecommend(article.getArticleId(),checkUser,regDate);
						article.setRecommend(article.getRecommend()+1);
						articleView.printArticlesOnly(article);
					}
				}
				else if(readCmd.equals("3")) {
					update(article);
					break;
					}
				else if(readCmd.equals("4")) {
					deleteArticle(article);
					break;
					}
				else if(readCmd.equals("5")) {
					break;
				}
				else {
					System.out.println("지원하지 않는 기능입니다.");
					break;
				}
				
			}
		}
	

	
	private void deleteLike(boolean target) {
			
			
		}


	private void addReply(Article article) {
		System.out.print("댓글 내용을 입력해주세요 : ");
		String articleReply = sc.nextLine();
		repo.addReplis(article.getArticleId(), articleReply, loginedMember.getMemberNickname());
		System.out.println("댓글이 등록되었습니다.");
	}
	public void deleteArticle(Article article) {		
		if(article.getNickname()==loginedMember.getMemberNickname()) {
			repo.deleteArticle(article);		
			System.out.println("삭제가 완료되었습니다.");
		}
		else {
			System.out.println("작성자만 삭제할 수 있습니다.");
		}
	}
	
	public void addMember() {
		System.out.println("==== 회원가입을 진행합니다. ====");
		System.out.println("아이디를 입력해주세요 : ");
		String memberId = sc.nextLine();
		System.out.println("비밀번호를 입력해주세요 : ");
		String memberPassword = sc.nextLine();
		System.out.println("닉네임을 입력해주세요 : ");
		String memberNickname = sc.nextLine();
		System.out.println("==== 회원가입이 완료되었습니다. ====");
		repo.doAddMember(memberId,memberPassword,memberNickname);
		}
	
	public void login() {
		System.out.println("아이디를 입력해주세요 : ");
		String loginId = sc.nextLine();
		System.out.println("비밀번호를 입력해주세요 : ");
		String loginPassword = sc.nextLine();
		//		repo.doLogin(loginId,loginPassword);
		//repo.doLogin 결과 return으로 1,2,3출력됨.때문에 int 변수에 값을 저장해줘야함.
		doLoginFlag loginResult = repo.doLogin(loginId, loginPassword);
		
//		if(loginResult==1) {
//			System.out.println("로그인 성공입니다.");
//		}else if(loginResult==2) {
//			System.out.println("없는 아이디거나 틀린 아이디입니다.");
//		}else {
//			System.out.println("비밀번호가 틀렸습니다.");
		 // 1,2 로 직접 받는것보다 위의 final int값으로 받는게 더 정확.
			if(loginResult==doLoginFlag.LOGIN_SUCCESS) {
				Member member = repo.getMemberByLoginId(loginId);
				loginSuccessProcess(member);
					
				}else if(loginResult==doLoginFlag.LOGIN_FAILEDID) {
					System.out.println("없는 아이디거나 틀린 아이디입니다.");
					
				}else {
					System.out.println("비밀번호가 틀렸습니다.");
				}
		}
	
	private void loginSuccessProcess(Member member){//로그인유저 정보 세팅. 
		System.out.printf("%s님 안녕하세요!\n",member.getMemberNickname());
		loginedMember = member;
	}
	private void doLogout() {
		if(loginedMember==null) {
			System.out.println("로그인이 필요한 기능입니다.");
			}
		else {
			loginedMember = null;
		}
	}
}

