package test;

public class ArticleLike {
	int ArticleId;
	String ArticleLikeUser;
	String LikeRegDate;
	int likeFlag;
		public ArticleLike(int ArticleId, String ArticleLikeUser, String LikeRegDate,int likeFlag) {
			this.ArticleId = ArticleId;
			this.ArticleLikeUser = ArticleLikeUser;
			this.LikeRegDate = LikeRegDate;
			this.likeFlag = likeFlag; // 
		}
		public int getLikeFlag() {
			return likeFlag;
		}
		public void setLikeFlag(int likeFlag) {
			this.likeFlag = likeFlag;
		}
		public int getArticleId() {
			return ArticleId;
		}
		public void setArticleId(int articleId) {
			ArticleId = articleId;
		}
		public String getArticleLikeUser() {
			return ArticleLikeUser;
		}
		public void setArticleLikeUser(String articleLikeUser) {
			ArticleLikeUser = articleLikeUser;
		}
		public String getLikeRegDate() {
			return LikeRegDate;
		}
		public void setLikeRegDate(String likeRegDate) {
			LikeRegDate = likeRegDate;
		}
}
