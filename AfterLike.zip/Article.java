package test;

public class Article {
		int articleId;
		String title;
		String body;
		int view;
		String nickname;
		String regDate;
		int recommend;
		String Id;
		
		public Article(int articleId,String title,String body,int view,String nickname,String regDate,int recommend, String Id){
				this.articleId = articleId;
				this.title = title;
				this.body = body;
				this.view = view;
				this.nickname = nickname;
				this.regDate = regDate;
				this.recommend = recommend;
				this.Id=Id;
		}
		
		public String getId() {
			return Id;
		}

		public void setId(String id) {
			Id = id;
		}

		public int getRecommend() {
			return recommend;
		}
		public void setRecommend(int recommend) {
			this.recommend = recommend;
		}
		public int getArticleId() {
			return articleId;
		}
		public void setArticleId(int articleId) {
			this.articleId = articleId;
		}
		public String getNickname() {
			return nickname;
		}
		public void setNickname(String nickname) {
			this.nickname = nickname;
		}
		public String getRegDate() {
			return regDate;
		}
		public void setRegDate(String regDate) {
			this.regDate = regDate;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
		public int getView() {
			return view;
		}
		public void setView(int view) {
			this.view = view;
		}
}
