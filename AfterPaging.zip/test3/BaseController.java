package test3;

import java.util.ArrayList;
import java.util.Scanner;
//public 공공
//protected 상속+같은클래스
//default 같은패키지
//public 자기자신
public class BaseController {
	doLoginFlag flag;
	ArrayList<Article> articles = new ArrayList<>();
	ArticleView articleView = new ArticleView();
	ApplicationData application;
	ArticleRepository repo = new ArticleRepository();
	Scanner sc = new Scanner(System.in);
	
	
	public BaseController(ApplicationData application) {
		this.application = application;
	}
	
	protected boolean isLogined() {
		if(application.getLoginedMember() == null) {
			System.out.println("로그인이 필요한 기능입니다.");
			return false;
		}
		return true;
	}
}
