package test3;

import java.util.Scanner;

public class EnumExample {
	boolean isLoginFlag = false; //(로그인성공 후 True로 바꿔주기)
	BoardPractice BP = new BoardPractice();
	
	public static void main(String[] args) {

		//변수 -> 소문자 (카멜표기법 의미가 바뀔때 대문자)
		//상수 -> 대문자 (언더바 표기법 _ _)
		// int season ; ENUM생성후
		final int successed =1;
		final int failed = 2;
		
		Season season = Season.SPRING; //클래스와 비슷한 Enum / Class이름 변수명 = 클래스명.Enum내부 데이터 명; 
		ResultCode Flag = ResultCode.SUCCESSED;

		Scanner sc = new Scanner(System.in);
		String ID;
		String PW;
		
//		repo.getMemberId. (앞에지정해주기)
//		Member member = repo.getMemberId
		
//		LoginFlag result = repo.doLogin(loginId, loginPw);
//		
//		loginSuccessProcess();
//	
		//로그인 직후 멤버가로그인한사람의 정보. 그걸 갖고와야함. 하지만함수가 다름 . 같이쓰거나 넘겨주거나 해야하지만 넘겨주려면 return을사용
		//혹은 Member loginedMember = null; 새로 만든 후 로그인후 loginedMember에 넣어주고 그걸 불러오면됨.
		//
		
	}
	public void loginSuccessProcess(Member member){
		System.out.printf("환영인사 %s님반갑", BP.loginedMember.getMemberNickname(),BP.loginedMember.getMemberId());
	}
}
//public enum 쓰면 해당파일 내에서 대표적 class를 퍼블릭할지 말지 결정하고 enum은 그에 속하기에 굳이 퍼블릭화하지않는다.
//enum을 퍼블릭화하려면 new create enum 하면 되며 그럴 시 타 클래스, 타 사용자와 공유하게된다.

enum Season {
	SPRING,//0  값을 지정하지 않으면 0부터시작.
	SUMMER,//1
	FALL,//2
	WINTER //3
}
enum ResultCode {
	SUCCESSED,
	FAILED;
}
