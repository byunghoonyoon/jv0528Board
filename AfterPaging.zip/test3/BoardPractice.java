package test3;

import java.util.Scanner;


public class BoardPractice {
	doLoginFlag flag;
	ApplicationData application = new ApplicationData();
	ArticleView articleView = new ArticleView();
	Scanner sc = new Scanner(System.in);
	Member loginedMember = null;
	articleController ac = new articleController(application);
	memberController mc = new memberController(application);
	
//	private final int LOGIN_SUCCESS = 0;
//	private final int LOGIN_FAILED_ID = 1;
//	private final int LOGIN_FAILED_PW = 2;
	
//	리팩토링View V
//	제어 C -> Board 데이터가 필요하면 M (repo)에서 꺼내오고 실행. 
//	데이터 M ->MV 모델과 뷰를 C제어한다MVC 
	// 게시물, 회원으로 분리. 게시판도 질문게시판,자유게시판등 여러개 필요하기에 모듈화필요. 회원도 마찬가지.
	public void run(){
		articleView.help();
		while(true){
			cmd();
			String cmd = sc.nextLine();
			
			String[] splitedCmd = cmd.split(" ");
			if(splitedCmd.length < 2) {
				System.out.println("잘못된 명령어 입니다.");
				continue;
			}
			
			String module = splitedCmd[0];
			String Action = splitedCmd[1];
			
			if(module.equals("article")) {
				ac.doCommand(Action);
			}
			else if(module.equals("member")) {
				mc.doCommand(Action);
			}
			else if(module.equals("common")) {
				
				if(cmd.equals("help")) {
					articleView.help();
				}
				else if(cmd.equals("exit")){
					System.out.println("시스템을 종료합니다.");
					break;
				}
			}
		}
	}
	private void cmd() {
		if(loginedMember!=null) {
			System.out.printf("명령어를 입력해주세요 : \n");
			System.out.printf("(%s(%s)) >> \n",loginedMember.getMemberId(),loginedMember.getMemberNickname());
			}

		else {
			System.out.println("명령어를 입력해주세요 : ");
			System.out.println(">> ");
		}	
	}
}


	
	