package test3;

import java.util.ArrayList;

public class articleController extends BaseController{
	ApplicationData application = null;
	
	public articleController(ApplicationData application){
		super(application);
		this.application = application;
		repo.addtestdata();
		Member loginedMember = repo.getMemberByLoginId("qqqq");
		application.setLoginedMember(loginedMember);
	}
	
	public void doCommand(String cmd) {
//		리팩토링View V
//		제어 C -> Board 데이터가 필요하면 M (repo)에서 꺼내오고 실행. 
//		데이터 M ->MV 모델과 뷰를 C제어한다MVC 
		// 게시물, 회원으로 분리. 게시판도 질문게시판,자유게시판등 여러개 필요하기에 모듈화필요. 회원도 마찬가지.
					
				if(cmd.equals("help")) {
					articleView.help();
					}
				else if(cmd.equals("add")) {
					addArticles();	
					}
				else if(cmd.equals("list")) {
					articleView.printArticles(repo.getArticleList());
					}
				else if(cmd.equals("page")) {
					
				}
				else if(cmd.equals("search")) {
					searchArticles();
					}
				else if(cmd.equals("read")) {
					read();
					}
				else {
					System.out.println("잘못된 명령어입니다.");
					}
	}
				
	
		public void searchArticles() {
			System.out.println("검색 키워드를 입력해주세요 : ");
			String keyword = sc.nextLine();
			
			ArrayList<Article> searchedList = (ArrayList<Article>) repo.getSearchedArticleList(keyword);
			articleView.printArticles(searchedList);
		}
		
		public void addArticles() {
			if(application.getLoginedMember()!=null) {
				System.out.print("제목을 입력해주세요 : ");
				String title = sc.nextLine();
				System.out.print("내용을 입력해주세요 : ");
				String body = sc.nextLine();
			
				System.out.printf("등록날짜 : %s\n",Util.getCurrentDate());
				System.out.printf("작성자 : %s\n",application.getLoginedMember().getMemberNickname());		
				System.out.println("게시물이 저장되었습니다.");
				repo.addArticle(title, body,application.getLoginedMember().getMemberNickname());
				}
			
			else {
				System.out.println("로그인이 필요한 기능입니다.");
			}
		}
		public void update(Article article) {
			if(article.getNickname()==application.getLoginedMember().getMemberNickname()) {
				System.out.println("새제목 : ");
				String title = sc.nextLine();
				System.out.println("새내용 : ");
				String body = sc.nextLine();
				
				repo.updateArticle(article, title, body);
				System.out.println("수정이 완료되었습니다.");
				articleView.printArticles(repo.getArticleList());
			}
			else {
				System.out.println("작성자만 수정할 수 있습니다.");
			}
		}
		public void read() {
			if(application.getLoginedMember()==null) {
				System.out.println("로그인이 필요한 기능입니다.");
				}
			
			else {
				System.out.println("상세보기할 게시물 번호를 입력해주세요 : ");
				
				int targetId = Integer.parseInt(sc.nextLine());
				Article article = repo.getArticleOne(targetId);
			
				if(article == null) {
					System.out.println("없는 게시물입니다.");
					} 
				else {
					repo.increaseReadCnt(article);
					articleView.printArticlesOnly(article);
					readprocess(article);
					}
			
			}
		}
			private void readprocess(Article article) {
				while(true) {
					System.out.println("상세보기 기능을 선택해주세요(1. 댓글 등록, 2. 좋아요, 3. 수정, 4. 삭제, 5. 목록으로) : ");
					String readCmd = sc.nextLine();
					
					if(readCmd.equals("1")) {
						addReply(article);
						ArrayList<Replis> replis = repo.getRepliesByArticleId(article.getArticleId());
						articleView.printArticlesDetail(article, replis);
						}
					else if(readCmd.equals("2")) {
						String checkUser = application.getLoginedMember().getMemberId();
						String regDate = Util.getCurrentDate();
//						boolean target = repo.checkLikeByUserId(checkUser,article);
						if(repo.checkLikeByUserId(checkUser,article)) {
							System.out.println("이미 좋아요를 체크하셨습니다.");
//							deleteLike(target);
//							article.setRecommend(article.getRecommend()-1);
//							articleView.printArticlesOnly(article);
						}
						else {
							repo.addRecommend(article.getArticleId(),checkUser,regDate);
							article.setRecommend(article.getRecommend()+1);
							articleView.printArticlesOnly(article);
						}
					}
					else if(readCmd.equals("3")) {
						update(article);
						break;
						}
					else if(readCmd.equals("4")) {
						deleteArticle(article);
						break;
						}
					else if(readCmd.equals("5")) {
						break;
					}
					else {
						System.out.println("지원하지 않는 기능입니다.");
						break;
					}
					
				}
			}
		

		
		private void deleteLike(boolean target) {
				
				
			}


		private void addReply(Article article) {
			System.out.print("댓글 내용을 입력해주세요 : ");
			String articleReply = sc.nextLine();
			repo.addReplis(article.getArticleId(), articleReply, application.getLoginedMember().getMemberNickname());
			System.out.println("댓글이 등록되었습니다.");
		}
		public void deleteArticle(Article article) {		
			if(article.getNickname()==application.getLoginedMember().getMemberNickname()) {
				repo.deleteArticle(article);		
				System.out.println("삭제가 완료되었습니다.");
			}
			else {
				System.out.println("작성자만 삭제할 수 있습니다.");
			}
		}
	}
