package test3;

public class Replis {
		int articleId;
		int ID;
		String replisNickname;
		String replisBody;
		String replisRegDate;
		
			public Replis(int ID,int articleId,String replisNickname,String replisBody,String replisRegDate) {
				this.replisNickname=replisNickname;
				this.ID=ID;
				this.replisBody=replisBody;
				this.replisRegDate=replisRegDate;
				this.articleId=articleId;
			}
			public int getArticleId() {
				return articleId;
			}
			public void setArticleId(int articleId) {
				this.articleId = articleId;
			}
			public int getID() {
				return ID;
			}
			public void setID(int ID) {
				this.ID = ID;
			}
			public String getReplisNickname() {
				return replisNickname;
			}
			public void setReplisNickname(String replisNickname) {
				this.replisNickname = replisNickname;
			}
			public String getReplisBody() {
				return replisBody;
			}
			public void setReplisBody(String replisBody) {
				this.replisBody = replisBody;
			}
			public String getReplisRegDate() {
				return replisRegDate;
			}
			public void setReplisRegDate(String replisRegDate) {
				this.replisRegDate = replisRegDate;
			}

	}


