package test3;

public class PagingTest {

	public static void main(String[] args) {
		int pageCountPerBlock = 5;
		int currentPageNo = 1; 
		
		int currentPageBlock = (int)Math.ceil((double)currentPageNo / pageCountPerBlock);//1블럭이면 1~5 2블럭이면 6~10
		int startPageNo = 1+(pageCountPerBlock*(currentPageBlock-1));
		int endPageNo = startPageNo+pageCountPerBlock;
		
//		cp : 1~5 b:1 -> cp/5 - 0.xxx 2/5 - 0.xxx 5/5 ->1 
//		cp: 6~10 b:2 -> 6/5 - 1.xx /5- 0.xxx 10/5 ->2
		// 현재페이지번호 / 페이지블럭당 페이지개수 (5) 후 올림 = 현재페이지블럭번호
		
		for(int i=startPageNo;i<endPageNo;i++) {
			if(i==currentPageNo) {
				System.out.printf("[%d] ",i);
			}
			else {
				System.out.printf("%d ",i);
			}
		}
	

	}

}
